gsap.registerPlugin(ScrollTrigger);
document.addEventListener("DOMContentLoaded", function() {
    gsap.from('#home',{
        opacity:0,
        duration: 2,
        ease: "linear"
    },'a');
    gsap.from('#projects',{
       opacity: 0,
        duration: 2,
        ease: "linear"
    },'a');
});










let navBar = document.querySelector('.nav-links');

function openMenu(){
    navBar.style.right = "0";
    gsap.from('.svg_2',{
        // rotation:360,
        opacity:0,
        duration:2,
        x:'2rem',
        ease:'circ.inOut'
    });
}

function hideMenu() {
    navBar.style.right = "-100%";
    gsap.from('.svg_2',{
        // rotation:360,
        y: '-10rem',
        duration:1,
        ease:'circ.inOut'
    });
}

function isSmallDevice() {
    return window.innerWidth < 768; // Adjust the breakpoint as needed
  }
  
  // Hide the navbar by default on small devices
  if (isSmallDevice()) {
    hideMenu();
};




const texts = ['UX Design • UI Design • Ramailo', 'Programming • Figma • Protopie'];
let index = 0;
let currentText = '';
let letter = '';
let isDeleting = false;

function autoWrite() {
  if (index === texts.length) {
    index = 0;
  }

  currentText = texts[index];

  if (isDeleting) {
    letter = currentText.slice(0, --letter.length);
  } else {
    letter = currentText.slice(0, ++letter.length);
  }

  document.getElementById('main-text').textContent = letter;

  if (letter.length === currentText.length && !isDeleting) {
    isDeleting = true;
    setTimeout(autoWrite, 500);
  } else if (letter.length === 0 && isDeleting) {
    isDeleting = false;
    index++;
    setTimeout(autoWrite, 500);
  } else {
    setTimeout(autoWrite, 200);
  }
}

autoWrite();
